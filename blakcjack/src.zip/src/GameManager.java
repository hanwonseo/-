
public class GameManager {

	public static void main(String[] args) {
		Game.play();
	}

}
