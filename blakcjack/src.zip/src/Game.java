import java.util.Scanner;

public class Game {
	static boolean gameRun = true;

	static void play() {
		Scanner sc = new Scanner(System.in);
		Deck deck = new Deck();
		Player player = new Player();
		Dealer dealer = new Dealer();

		// boolean gameRun = true;
		boolean playerRun = true;
		int betting;

		System.out.println("게임을 시작합니다.");
		System.out.print("시작 자금을 입력하시오>");
		int wallet = sc.nextInt();
		player.setWallet(wallet);

		while (gameRun) {
			System.out.println("플레이어의 현재 자금: " + player.getWallet());
			System.out.print("배팅할 금액을 입력하시오>");
			betting = sc.nextInt();

			if (betting == 0 || betting > player.getWallet()) {
				System.out.println("유효한 배팅금을 입력하십시오");
				continue;
			}

			player.subtractWallet(betting);
			System.out.println("플레이어의 현재 자금: " + player.getWallet()); // 디버그

			// 첫 카드 드로우 코드
			player.addCard(deck.drawCard());
			dealer.addCard(deck.drawCard());
			player.addCard(deck.drawCard());
			dealer.addCard(deck.drawCard());

			System.out.println("베팅한 금액: " + betting);
			System.out.println("딜러 카드: " + dealer.getHand().get(0) + " (가려진 카드)");
			System.out.println("플레이어 카드: " + player.getHand());
			
			Rule.Blackjack(betting, player);
			Rule.Insurance(betting, player, dealer);
			
			// hit 또는 stand 선택하며 진행
			while (playerRun && gameRun) {
				System.out.println("어떤 액션을 선택하시겠습니까? (히트, 스탠드)");
				String action = sc.next();

				switch (action) {
				case "히트":
					Card playerCard = deck.drawCard();
					player.addCard(playerCard);
					System.out.println("플레이어가 " + playerCard + "를 받았습니다.");
					System.out.println("플레이어 카드: " + player.getHand());

					Rule.Bust(betting, player, dealer);
					Rule.Push(betting, player, dealer);
					break;

				case "스탠드":
					System.out.println("플레이어가 스탠드를 선택했습니다.");
					System.out.println("딜러 카드: " + dealer.getHand());
					while (dealer.getHandValue() < 17) {
						Card dealererCard = deck.drawCard();
						dealer.addCard(dealererCard);
						System.out.println("딜러 카드: " + dealer.getHand());
						Rule.Bust(betting, player, dealer);
						Rule.Push(betting, player, dealer);
					}
					Rule.Result(betting, player, dealer);
					gameRun = false;
					playerRun = false;
					break;

				default:
					System.out.println("올바른 액션을 선택해주세요.");
					break;
				}
			}

			player.resetHand();
			dealer.resetHand();

			if (player.getWallet() <= 0) {
				System.out.println("자금이 모두 소진되었습니다.");
				gameRun = false;
			} else {
				// 게임 재시작 여부 확인
				System.out.println("계속해서 플레이하시겠습니까? (예, 아니오)");
				String restart = sc.next();

				if (restart.equals("예")) {
					gameRun = true;
					playerRun = true;
				}
			}

		}

		System.out.println("게임 종료.");
		sc.close();
	}
}
