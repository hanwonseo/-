import java.util.Scanner;

class Rule {
	public static void Blackjack(int betting, Player player) {
		if (player.getHandValue() == 21) {
			System.out.println("블랙잭! 플레이어 승리!");
			player.addWallet((int) (betting * 1.5));
		}
	}

	public static void Bust(int betting, Player player, Dealer dealer) {
		if (player.getHandValue() > 21) {
			System.out.println("딜러 카드: " + dealer.getHand());
			System.out.println("플레이어 버스트! 딜러 승리!");
			Game.gameRun=false;
		} else if (dealer.getHandValue() > 21) {
			System.out.println("딜러 카드: " + dealer.getHand());
			System.out.println("딜러 버스트! 플레이어 승리!");
			player.addWallet(betting * 2);
			Game.gameRun=false;
		}
	}

	public static void Push(int betting, Player player, Dealer dealer) {
		if (player.getHandValue() == dealer.getHandValue()) {
			System.out.println("딜러 카드: " + dealer.getHand());
			System.out.println("푸시! 무승부!");
			player.addWallet(betting);
			Game.gameRun=false;
		}
	}
	
	public static void Insurance(int betting, Player player, Dealer dealer) {
		Card dealerOpenCard = dealer.getHand().get(0);
		if (dealerOpenCard.getValue() == 11) {
			System.out.println("인슈어런스를 선택하시겠습니까? (예, 아니오)");
			Scanner sc = new Scanner(System.in);
			String input = sc.nextLine();

			if (input.equals("예")) {
				int insuranceAmount = (int) (betting * 0.5);
				if (player.getWallet() >= insuranceAmount) {
					player.subtractWallet(insuranceAmount);
					System.out.println("인슈어런스 베팅금액: "  + insuranceAmount);

					if (dealer.getHandValue() == 21) {
						System.out.println("딜러의 패가 블랙잭입니다. 인슈어런스에 걸린 보험금을 받습니다.");
						player.addWallet(insuranceAmount * 3);
						Game.gameRun=false;
					} else {
						System.out.println("인슈어런스에 걸린 보험금은 소실되었습니다.");
					}
				} else {
					System.out.println("보유한 자금으로 인슈어런스를 걸 수 없습니다.");
				}
			}
			sc.close();
		}
	}

	public static void Result(int betting, Player player, Dealer dealer) {
		if(player.getHandValue() < 22 && dealer.getHandValue() < 22) {
		if (player.getHandValue() > dealer.getHandValue()) {
			System.out.println("플레이어 승리!");
			player.addWallet(betting * 2);
		} else if (player.getHandValue() < dealer.getHandValue()) {
			System.out.println("딜러 승리!");
		}
		}
	}
}